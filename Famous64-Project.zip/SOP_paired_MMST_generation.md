# Standard Operating Procedure (SOP)
## Production File Generation for Paired MMST (MMST)

This document outlines the standard operating procedure for generating production files for paired MMST. Follow the steps sequentially to complete the validation and processing.

---

### **Document Control**
* **Procedure Name:** Production File Generation for Paired MMST
* **Target System:** Banglalink Inventory & Interfaces (Django backend command-line utilities)
* **Output Path:** `/mnt/store/sims`
* **Status:** Approved (SQL Queries Unchanged as Instructed)

---

### **Overview Flow**

```mermaid
graph TD
    A[Start: Acquire MSISDNs] --> B[Step 1.1: Run Stock Validation Query]
    B --> C[Step 1.2: Format Output with Excel/Shell]
    C --> D[Step 1.3: Run Django dbshell Command]
    D --> E[Step 2.1: Transfer to Local via WinSCP]
    E --> F[Step 2.2: Add Headers & Check IMSI Series]
    F --> G[Step 2.3: Upload to Server & Set 777 Permissions]
    G --> H[Step 2.4: Run batch_imsi_icc Django Script]
    H --> I[End: Verify output in /mnt/store/sims]
```

---

### **Step 1: MSISDN Extraction & Initial Validation**

#### **1.1. Execute Validation SQL Query**
Run the following query in your database tool or shell to validate the status and stock eligibility of target MSISDNs.

> [!IMPORTANT]  
> The SQL query below must be executed exactly as shown in the production reference (including any column/table naming conventions and quote formatting):

```sql
select maisdn from number_stock_maisdn where reserved_for='' and status='available' and stock In (0,16) and number_category=9 and maisdn not in (select maisdn_id from number_stock_sim where maisdn_id in (
'8801971035423',
'8801941366774')) and maisdn in (
8801971035423',
'8801941366774');
```

*Excel helper formula for wrapping input cell values:*
```excel
=""""&A26&"",""
```

---

#### **1.2. Server Execution and Shell Operations**

1. **Log in to the Application Server**
   Log in as the `webappl` user and assume the roles of the `web` application user using `dzdo`:
   ```bash
   login webappl dzdo -iu web
   ```

2. **Navigate to the Temporary Directory**
   ```bash
   cd /tmp
   ```

3. **Create the Input Text File**
   Create or edit the query input file (e.g., `Msisdn_Status_Check_20260512_2.txt`):
   ```bash
   vi /tmp/Msisdn_Status_Check_20260512_2.txt
   ```
   *Paste the SQL query from Step 1.1 into this file and save (`:wq`).*

4. **Run the Database Shell Utility**
   Pipe the text file into Django's `dbshell` to execute the query and dump the results to a CSV file:
   ```bash
   /apps/banglalink/interfaces/control/manage.py dbshell < /tmp/Msisdn_Status_Check_20260512_2.txt > /tmp/validated_data_20260512_2.csv
   ```
   
   > [!NOTE]  
   > * Depending on the active execution or environment standard, the output file pattern can be named as `/tmp/Validated_data_YYYYMMDD_X.csv` (e.g., `/tmp/Validated_data_20260310_5.csv`).

5. **Verify Row Count**
   Check the line count of the generated validation output file to verify data presence:
   ```bash
   wc -l Validated_data_20260310_3.csv
   ```

---

### **Step 2: Local Processing, Headers Enrichment & Execution**

#### **2.1. File Transfer & Copy Preparation**
1. Use **WinSCP** (or any SFTP client) to download a copy of the generated validation CSV from the server to your local machine.
2. Rename the downloaded file according to the current production date format (e.g., `Production_data_20260504_1.csv`).

---

#### **2.2. Format Enrichment & Header Insertion**
1. Open the CSV file using a spreadsheet editor or text editor.
2. Ensure the CSV conforms to the following structured headers and format:

##### **CSV Header Format:**
```text
msisdn,imsi_number,payment_type,vendor_id,print_msisdn,product_name
8801986127227,4700399067504634,prepaid,IF,Y,MMST
```

---

#### **2.3. IMSI and ICC ID Range Verification Query**
Execute the query below to check and verify the IMSI and ICC status, grouping by status and access control to ensure consistency before batch processing:

```sql
select status, access_control,min(imsi),max(imsi),count(*) from number_stock_sim where imsi between '470039900000000' and '470039999999999' and vendor_id='IF' group by status, access_control;
```

---

#### **2.4. Server Upload & Django Command Execution**

1. Upload the modified production data file (e.g., `Production_data_20260513_2.csv`) back to the server `/tmp/` folder via WinSCP.
2. Modify the file permissions so the system execution user can access it:
   ```bash
   chmod 777 /tmp/Production_data_20260513_2.csv
   ```
3. Run the batch IMSI/ICC provisioning script using the Django admin command utility:
   ```bash
   /apps/banglalink/inventory/manage.py batch_imsi_icc --sim-csv-file=/tmp/Production_data_20260513_2.csv
   ```

---

### **Output & Verification**
Once the execution completes successfully, verify that the output files have been generated at the following path:
* **Output Path:** `/mnt/store/sims`
* Use `ls -la /mnt/store/sims` to check files.
