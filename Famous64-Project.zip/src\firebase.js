import { initializeApp } from "firebase/app";
import { getFirestore, doc, setDoc, onSnapshot, getDoc } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAmijB6ApqXz9t5yk17Pds9hO1ZyFx69EI",
  authDomain: "messsync-d45ef.firebaseapp.com",
  projectId: "messsync-d45ef",
  storageBucket: "messsync-d45ef.firebasestorage.app",
  messagingSenderId: "868221380702",
  appId: "1:868221380702:web:4cb602bf8ad5e05bbb2ccf",
  measurementId: "G-7CB2ZPDB16"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

// Helper functions for our single-document database architecture
const DOC_REF = doc(db, 'appData', 'main');

// Initial Data Structure
const initialData = {
  deposits: { Shahadat: 753, Anwar: 887, Mohsin: 276, Salim: 1223, Nahid: 1850 },
  meals: [
    { id: 1, date: '2026-04-01', counts: { Shahadat: 1.5, Anwar: 1.5, Mohsin: 0.5, Salim: 0, Nahid: 0 } },
    { id: 2, date: '2026-04-02', counts: { Shahadat: 1.5, Anwar: 1.5, Mohsin: 0, Salim: 3, Nahid: 0.5 } },
    { id: 3, date: '2026-04-03', counts: { Shahadat: 1.5, Anwar: 1.5, Mohsin: 0, Salim: 2, Nahid: 0 } },
  ],
  markets: [
    { id: 1, date: '2026-04-07', marketer: 'Nahid', amount: 500 },
    { id: 2, date: '2026-04-09', marketer: 'Nahid', amount: 40 },
    { id: 3, date: '2026-04-12', marketer: 'Nahid/Salim', amount: 1270 },
    { id: 4, date: '2026-04-14', marketer: 'Nahid', amount: 480 },
  ],
  fixedExpenses: [
    { id: 1, type: 'H. Rent', total: 19500, splits: { Shahadat: 3900, Anwar: 3900, Mohsin: 3900, Salim: 3900, Nahid: 3900 } },
    { id: 2, type: 'Cooking', total: 3000, splits: { Shahadat: 600, Anwar: 600, Mohsin: 600, Salim: 600, Nahid: 600 } },
    { id: 3, type: 'Parking', total: 500, splits: { Shahadat: 0, Anwar: 0, Mohsin: 0, Salim: 500, Nahid: 0 } },
  ]
};

// Initialize DB if empty
export const initializeDbIfEmpty = async () => {
  try {
    const docSnap = await getDoc(DOC_REF);
    if (!docSnap.exists()) {
      await setDoc(DOC_REF, initialData);
      console.log("Initialized Firestore with default data!");
    }
  } catch (error) {
    console.error("Error initializing DB. Did you set Firestore rules to public?", error);
  }
};

// Subscribe to real-time changes
export const subscribeToData = (callback, errorCallback) => {
  return onSnapshot(DOC_REF, (docSnap) => {
    if (docSnap.exists()) {
      callback(docSnap.data());
    } else {
      // Unblock the UI immediately by returning default data while DB initializes
      callback(initialData);
    }
  }, (error) => {
    console.error("Firestore Listen Error: ", error);
    if (errorCallback) errorCallback(error.message);
  });
};

// Update Data in Firestore
export const syncToFirestore = async (newDataMap) => {
  try {
    await setDoc(DOC_REF, newDataMap, { merge: true });
  } catch (error) {
    console.error("Error syncing to Firestore: ", error);
  }
};
