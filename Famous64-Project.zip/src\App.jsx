import { useState, useEffect, useMemo } from 'react';
import { BrowserRouter as Router, Routes, Route, NavLink, Link, useNavigate, useSearchParams, useLocation } from 'react-router-dom';
import { 
  Home as HomeIcon, MapPin, Search, ShoppingBag, ShoppingCart, Percent, BookOpen, 
  Mail, FileText, Settings, Plus, Minus, Trash2, Star, CheckCircle, Calendar, 
  DollarSign, Clock, ArrowRight, ChevronRight, Filter, Sparkles, Globe, Users, 
  Award, ShieldCheck, Heart 
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { DIVISIONS, DISTRICTS, PRODUCTS, BLOG_POSTS, PROPOSAL_DATA, TRANSLATIONS } from './data';
import './App.css';

// --- Scroll To Top Helper ---
const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

// --- App Root ---
function App() {
  const [lang, setLang] = useState(() => {
    const saved = localStorage.getItem('famous64_lang');
    return saved === 'bn' ? 'bn' : 'en';
  });

  const [cart, setCart] = useState(() => {
    const saved = localStorage.getItem('famous64_cart');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [products, setProducts] = useState(() => {
    const saved = localStorage.getItem('famous64_products');
    return saved ? JSON.parse(saved) : PRODUCTS;
  });

  const [orders, setOrders] = useState(() => {
    const saved = localStorage.getItem('famous64_orders');
    return saved ? JSON.parse(saved) : [
      { id: "ORD-9821", name: "Anisur Rahman", phone: "01712345678", total: 1100, itemsCount: 3, payment: "bKash", status: "Shipped", date: "2026-05-25" },
      { id: "ORD-7643", name: "Tariqul Islam", phone: "01998765432", total: 450, itemsCount: 1, payment: "Cash on Delivery", status: "Pending", date: "2026-05-26" }
    ];
  });

  const [cartOpen, setCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [wishlist, setWishlist] = useState(() => {
    const saved = localStorage.getItem('famous64_wishlist');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('famous64_lang', lang);
  }, [lang]);

  useEffect(() => {
    localStorage.setItem('famous64_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('famous64_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('famous64_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('famous64_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  // Translation helper
  const t = (key) => {
    return TRANSLATIONS[lang][key] || key;
  };

  // Cart operations
  const addToCart = (product, qty = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.product.id === product.id 
            ? { ...item, quantity: item.quantity + qty } 
            : item
        );
      }
      return [...prev, { product, quantity: qty }];
    });
  };

  const updateCartQty = (productId, qty) => {
    if (qty <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev => prev.map(item => 
      item.product.id === productId ? { ...item, quantity: qty } : item
    ));
  };

  const removeFromCart = (productId) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (productId) => {
    setWishlist(prev => 
      prev.includes(productId) 
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  // Admin operations
  const addProductAdmin = (newProd) => {
    setProducts(prev => [newProd, ...prev]);
  };

  const updateOrderStatus = (orderId, newStatus) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
  };

  // Cart count
  const cartItemCount = useMemo(() => cart.reduce((sum, item) => sum + item.quantity, 0), [cart]);

  return (
    <Router>
      <ScrollToTop />
      <div className="app-container">
        {/* Navigation Bar */}
        <header className="main-navbar glass-panel">
          <div className="brand-logo">
            <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div className="logo-icon brand-icon"><Sparkles /></div>
              <div>
                <div className="brand-text">Famous64</div>
                <div className="brand-tagline">{t('tagline')}</div>
              </div>
            </Link>
          </div>

          <nav className="nav-menu">
            <NavLink to="/" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`} end>
              {t('home')}
            </NavLink>
            <NavLink to="/districts" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              {t('districts')}
            </NavLink>
            <NavLink to="/offers" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              {t('offers')}
            </NavLink>
            <NavLink to="/blog" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              {t('blog')}
            </NavLink>
            <NavLink to="/contact" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              {t('contact')}
            </NavLink>
            <NavLink to="/proposal" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`} style={{ color: 'var(--gold)' }}>
              {t('proposal')}
            </NavLink>
          </nav>

          <div className="navbar-actions">
            {/* Language Switcher */}
            <button 
              className="btn btn-outline" 
              onClick={() => setLang(lang === 'en' ? 'bn' : 'en')}
              style={{ padding: '6px 12px', fontSize: '0.85rem', borderColor: 'var(--gold)', color: 'var(--gold-light)' }}
            >
              <Globe size={14} style={{ marginRight: '6px' }} />
              {lang === 'en' ? 'বাংলা' : 'English'}
            </button>

            <NavLink to="/admin" className="icon-badge-btn" title={t('adminPanelTitle')}>
              <Settings size={20} />
            </NavLink>
            <button className="icon-badge-btn" onClick={() => setCartOpen(true)} title={t('cart')}>
              <ShoppingCart size={20} />
              {cartItemCount > 0 && <span className="badge-count">{cartItemCount}</span>}
            </button>
          </div>
        </header>

        {/* Main Pages Content */}
        <main className="page-content">
          <Routes>
            <Route path="/" element={<Home products={products} addToCart={addToCart} setSelectedProduct={setSelectedProduct} wishlist={wishlist} toggleWishlist={toggleWishlist} lang={lang} />} />
            <Route path="/districts" element={<DistrictBrowser products={products} addToCart={addToCart} setSelectedProduct={setSelectedProduct} wishlist={wishlist} toggleWishlist={toggleWishlist} lang={lang} />} />
            <Route path="/offers" element={<Offers addToCart={addToCart} setSelectedProduct={setSelectedProduct} products={products} lang={lang} />} />
            <Route path="/blog" element={<Blog lang={lang} />} />
            <Route path="/contact" element={<Contact lang={lang} />} />
            <Route path="/proposal" element={<Proposal lang={lang} />} />
            <Route path="/admin" element={<Admin products={products} orders={orders} addProductAdmin={addProductAdmin} updateOrderStatus={updateOrderStatus} lang={lang} />} />
            <Route path="/checkout" element={<Checkout cart={cart} clearCart={clearCart} orders={orders} setOrders={setOrders} lang={lang} />} />
          </Routes>
        </main>

        {/* Footer */}
        <footer style={{ marginTop: '80px', borderTop: '1px solid var(--border-color)', background: '#070b13', padding: '60px 40px 30px 40px' }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'grid', gridTemplateColumns: '1.5fr 1fr 1fr 1.2fr', gap: '40px', marginBottom: '40px' }}>
            <div>
              <h3 style={{ fontSize: '1.6rem', color: 'var(--gold-light)', marginBottom: '16px' }}>Famous64</h3>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: '20px', lineHeight: '1.6' }}>
                {lang === 'en' ? 'Discover the authentic local delicacies, unique handicrafts, clothing, and organic treasures hand-crafted across Bangladesh\'s 64 districts.' : 'বাংলাদেশের ৬৪ জেলায় দেশীয় ঐতিহ্য ও খাঁটি কারিগরদের তৈরি হরেক রকমের সুস্বাদু মিষ্টি, পোশাক, হস্তশিল্প ও প্রাকৃতিক পণ্য আবিষ্কার করুন।'}
              </p>
              <div style={{ display: 'flex', gap: '12px' }}>
                <span className="badge badge-success">🇧🇩 {lang === 'en' ? '64 Districts' : '৬৪ জেলা'}</span>
                <span className="badge badge-warning" style={{ background: 'var(--gold-glow)', color: 'var(--gold-light)' }}>🌿 {lang === 'en' ? '100% Authentic' : '১০০% খাঁটি পণ্য'}</span>
              </div>
            </div>
            <div>
              <h4 style={{ fontSize: '1.1rem', marginBottom: '20px', color: 'white' }}>{lang === 'en' ? 'Quick Links' : 'সহজ লিঙ্ক সমূহ'}</h4>
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '12px', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                <li><Link to="/districts">{t('browseAllDistricts')}</Link></li>
                <li><Link to="/offers">{lang === 'en' ? 'Current Offers' : 'চলতি অফার সমূহ'}</Link></li>
                <li><Link to="/blog">{lang === 'en' ? 'Artisan Stories Blog' : 'কারিগরদের গল্প ব্লগ'}</Link></li>
                <li><Link to="/contact">{lang === 'en' ? 'Get in Touch' : 'যোগাযোগ করুন'}</Link></li>
              </ul>
            </div>
            <div>
              <h4 style={{ fontSize: '1.1rem', marginBottom: '20px', color: 'white' }}>{lang === 'en' ? 'Key Divisions' : 'প্রধান বিভাগসমূহ'}</h4>
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '12px', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                <li><Link to="/districts?division=Dhaka">{lang === 'en' ? 'Dhaka Division' : 'ঢাকা বিভাগ'}</Link></li>
                <li><Link to="/districts?division=Rajshahi">{lang === 'en' ? 'Rajshahi Division' : 'রাজশাহী বিভাগ'}</Link></li>
                <li><Link to="/districts?division=Sylhet">{lang === 'en' ? 'Sylhet Division' : 'সিলেট বিভাগ'}</Link></li>
                <li><Link to="/districts?division=Chattogram">{lang === 'en' ? 'Chattogram Division' : 'চট্টগ্রাম বিভাগ'}</Link></li>
              </ul>
            </div>
            <div>
              <h4 style={{ fontSize: '1.1rem', marginBottom: '20px', color: 'white' }}>{t('sourcingAlerts')}</h4>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '16px' }}>
                {t('sourcingAlertsDesc')}
              </p>
              <div style={{ display: 'flex', gap: '8px' }}>
                <input type="email" placeholder={lang === 'en' ? 'Your email address' : 'আপনার ইমেইল ঠিকানা'} className="form-input" style={{ padding: '8px 12px', fontSize: '0.85rem' }} />
                <button className="btn btn-primary" style={{ padding: '8px 16px', fontSize: '0.85rem' }}>{t('subscribe')}</button>
              </div>
            </div>
          </div>
          <div style={{ borderTop: '1px solid rgba(255,255,255,0.05)', paddingTop: '24px', textAlign: 'center', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
            <p>{t('copyright')}</p>
          </div>
        </footer>

        {/* Global Cart Drawer */}
        <CartDrawer isOpen={cartOpen} onClose={() => setCartOpen(false)} cart={cart} updateCartQty={updateCartQty} removeFromCart={removeFromCart} lang={lang} />

        {/* Product Detail Modal */}
        <AnimatePresence>
          {selectedProduct && (
            <ProductDetailModal product={selectedProduct} onClose={() => setSelectedProduct(null)} addToCart={addToCart} wishlist={wishlist} toggleWishlist={toggleWishlist} lang={lang} />
          )}
        </AnimatePresence>
      </div>
    </Router>
  );
}

// --- Components ---

// 1. PRODUCT DETAIL MODAL
const ProductDetailModal = ({ product, onClose, addToCart, wishlist, toggleWishlist, lang }) => {
  const [qty, setQty] = useState(1);
  const isWishlisted = wishlist.includes(product.id);
  const t = (key) => TRANSLATIONS[lang][key] || key;

  return (
    <motion.div 
      className="modal-overlay"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div 
        className="product-detail-modal glass-panel"
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 50, opacity: 0 }}
        transition={{ type: "spring", damping: 25, stiffness: 200 }}
        onClick={e => e.stopPropagation()}
      >
        <button className="modal-close-btn" onClick={onClose}>×</button>
        
        <div className="detail-grid">
          <div className="detail-img-box">
            <img src={product.image} alt={product['name_' + lang] || product.name} />
          </div>
          <div className="detail-info">
            <div className="detail-meta-row">
              <span className="badge badge-success">📍 {lang === 'en' ? product.district : (DISTRICTS.find(d => d.name === product.district)?.name_bn || product.district)}</span>
              <span className="badge badge-warning" style={{ background: 'var(--gold-glow)', color: 'var(--gold)' }}>🏷️ {lang === 'en' ? product.category : (product.category === 'Food' ? 'খাবার ও মিষ্টি' : product.category === 'Clothing' ? 'ঐতিহ্যবাহী পোশাক' : product.category === 'Handicrafts' ? 'হস্তশিল্প' : 'প্রাকৃতিক')}</span>
            </div>
            
            <h2 className="detail-heading">{product['name_' + lang] || product.name}</h2>
            
            <div className="product-rating">
              <Star size={16} fill="currentColor" />
              <span>{product.rating} ({product.reviewsCount} {t('customerReviews')})</span>
            </div>
            
            <div className="detail-price">৳{product.price}</div>
            
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem', lineHeight: '1.6' }}>{product['description_' + lang] || product.description}</p>
            
            <div className="detail-story-box">
              <div className="detail-story-heading">{t('originStoryHeading')}</div>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{product['history_' + lang] || product.history}</p>
            </div>

            <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              <strong>{t('detailsTab')}</strong>{product['details_' + lang] || product.details}
            </div>
            
            <div className="quantity-control">
              <span className="form-label" style={{ marginBottom: 0, marginRight: '12px' }}>{t('quantity')}</span>
              <button className="quantity-btn" onClick={() => setQty(Math.max(1, qty - 1))}><Minus size={14} /></button>
              <span className="quantity-value">{qty}</span>
              <button className="quantity-btn" onClick={() => setQty(qty + 1)}><Plus size={14} /></button>
            </div>
            
            <div style={{ display: 'flex', gap: '16px', marginTop: '16px' }}>
              <button className="btn btn-primary" style={{ flex: 1, padding: '14px 24px' }} onClick={() => { addToCart(product, qty); onClose(); }}>
                <ShoppingBag size={18} /> {t('addToBasket')}{product.price * qty}
              </button>
              <button 
                className="btn btn-outline" 
                style={{ width: '50px', padding: 0, borderColor: isWishlisted ? 'var(--accent-red)' : 'var(--border-color)', color: isWishlisted ? 'var(--accent-red)' : 'white' }}
                onClick={() => toggleWishlist(product.id)}
              >
                <Heart size={20} fill={isWishlisted ? "currentColor" : "none"} />
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

// 2. GLOBAL CART DRAWER
const CartDrawer = ({ isOpen, onClose, cart, updateCartQty, removeFromCart, lang }) => {
  const [coupon, setCoupon] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [couponError, setCouponError] = useState('');
  const [couponSuccess, setCouponSuccess] = useState('');
  const navigate = useNavigate();
  const t = (key) => TRANSLATIONS[lang][key] || key;

  if (!isOpen) return null;

  const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const discount = Math.round(subtotal * (discountPercent / 100));
  const shipping = subtotal > 0 ? 80 : 0;
  const total = subtotal - discount + shipping;

  const handleApplyCoupon = () => {
    setCouponError('');
    setCouponSuccess('');
    const code = coupon.trim().toUpperCase();
    if (code === 'FAMOUS64') {
      setDiscountPercent(20);
      setCouponSuccess(`20% ${t('couponAppliedSuccess')}`);
    } else if (code === 'DESHI15') {
      setDiscountPercent(15);
      setCouponSuccess(`15% ${t('couponAppliedSuccess')}`);
    } else if (code === '') {
      setCouponError(t('enterCouponMsg'));
    } else {
      setCouponError(t('invalidCoupon'));
    }
  };

  return (
    <>
      <div className="cart-drawer-overlay" onClick={onClose}></div>
      <motion.div 
        className="cart-drawer"
        initial={{ x: 450 }}
        animate={{ x: 0 }}
        transition={{ type: "spring", damping: 30, stiffness: 250 }}
      >
        <div className="cart-header">
          <h2 style={{ margin: 0, fontSize: '1.4rem', color: 'white' }}>{t('cart')} ({cart.length})</h2>
          <button className="modal-close-btn" style={{ position: 'relative', top: 0, right: 0 }} onClick={onClose}>×</button>
        </div>

        <div className="cart-items-list">
          {cart.length === 0 ? (
            <div style={{ textAlign: 'center', margin: '80px 0', color: 'var(--text-secondary)' }}>
              <ShoppingCart size={48} style={{ opacity: 0.3, marginBottom: '16px' }} />
              <p>{t('emptyCart')}</p>
              <p style={{ fontSize: '0.85rem', marginTop: '8px' }}>{t('emptyCartHint')}</p>
            </div>
          ) : (
            cart.map(item => (
              <div className="cart-item" key={item.product.id}>
                <div className="cart-item-img">
                  <img src={item.product.image} alt={item.product['name_' + lang] || item.product.name} />
                </div>
                <div>
                  <div className="cart-item-name">{item.product['name_' + lang] || item.product.name}</div>
                  <div className="cart-item-district">📍 {lang === 'en' ? item.product.district : (DISTRICTS.find(d => d.name === item.product.district)?.name_bn || item.product.district)}</div>
                  <div className="cart-item-price">৳{item.product.price}</div>
                  <div className="quantity-control" style={{ transform: 'scale(0.85)', transformOrigin: 'left center', marginTop: '4px' }}>
                    <button className="quantity-btn" onClick={() => updateCartQty(item.product.id, item.quantity - 1)}><Minus size={12} /></button>
                    <span className="quantity-value">{item.quantity}</span>
                    <button className="quantity-btn" onClick={() => updateCartQty(item.product.id, item.quantity + 1)}><Plus size={12} /></button>
                  </div>
                </div>
                <div>
                  <button className="icon-badge-btn" style={{ color: 'var(--text-muted)' }} onClick={() => removeFromCart(item.product.id)}>
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {cart.length > 0 && (
          <div className="cart-footer">
            <div className="coupon-box">
              <input 
                type="text" 
                placeholder={t('couponPlaceholder')} 
                className="coupon-input"
                value={coupon}
                onChange={e => setCoupon(e.target.value)}
              />
              <button className="btn btn-outline" onClick={handleApplyCoupon} style={{ padding: '8px 16px', fontSize: '0.85rem' }}>{t('apply')}</button>
            </div>
            {couponError && <div style={{ fontSize: '0.75rem', color: 'var(--danger)' }}>{couponError}</div>}
            {couponSuccess && <div style={{ fontSize: '0.75rem', color: 'var(--success)' }}>{couponSuccess}</div>}
            
            <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '16px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <div className="cart-summary-row">
                <span>{t('subtotal')}</span>
                <span>৳{subtotal}</span>
              </div>
              {discount > 0 && (
                <div className="cart-summary-row" style={{ color: 'var(--success)' }}>
                  <span>{t('discount')} ({discountPercent}%):</span>
                  <span>-৳{discount}</span>
                </div>
              )}
              <div className="cart-summary-row">
                <span>{t('shipping')}</span>
                <span>৳{shipping}</span>
              </div>
              <div className="cart-summary-row cart-summary-total" style={{ marginTop: '8px', paddingTop: '8px', borderTop: '1px solid rgba(255,255,255,0.03)' }}>
                <span>{t('totalPayable')}</span>
                <span>৳{total}</span>
              </div>
            </div>

            <button 
              className="btn btn-accent" 
              style={{ width: '100%', padding: '14px', borderRadius: '12px', marginTop: '8px' }}
              onClick={() => { onClose(); navigate('/checkout'); }}
            >
              {t('secureCheckout')} <ArrowRight size={16} />
            </button>
          </div>
        )}
      </motion.div>
    </>
  );
};

// 3. HOME PAGE
const Home = ({ products, addToCart, setSelectedProduct, wishlist, toggleWishlist, lang }) => {
  const navigate = useNavigate();
  const [heroSearch, setHeroSearch] = useState('');
  const t = (key) => TRANSLATIONS[lang][key] || key;

  const featuredProducts = useMemo(() => {
    return products.filter(p => ["bogura_doi", "nayagarh_jamdani", "satkhira_honey", "sylhet_tea_leaves"].includes(p.id));
  }, [products]);

  const handleHeroSearchSubmit = (e) => {
    e.preventDefault();
    if (heroSearch.trim()) {
      navigate(`/districts?search=${encodeURIComponent(heroSearch.trim())}`);
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      {/* Hero Section */}
      <div className="hero-container">
        <div>
          <div className="hero-tagline">✨ {lang === 'en' ? 'Authentic Deshi Treasures' : 'খাঁটি দেশী পণ্য সম্ভার'}</div>
          <h1 className="hero-title">
            {lang === 'en' ? (
              <>Discover The Unique Treasures Of <span>Bangladesh</span></>
            ) : (
              <>আবিষ্কার করুন ৬৪ জেলার সেরা <span>ঐতিহ্যবাহী পণ্য</span></>
            )}
          </h1>
          <p className="hero-description">{t('heroDesc')}</p>
          <form onSubmit={handleHeroSearchSubmit} className="search-bar-hero">
            <Search size={20} style={{ color: 'var(--gold)' }} />
            <input 
              type="text" 
              placeholder={t('districtSearchPlaceholder')} 
              className="search-input-hero"
              value={heroSearch}
              onChange={e => setHeroSearch(e.target.value)}
            />
            <button type="submit" className="btn btn-primary" style={{ borderRadius: '10px' }}>{t('exploreBtn')}</button>
          </form>
        </div>
        <div className="hero-visual">
          <div className="hero-backdrop-glow"></div>
          <div className="hero-image-wrapper">
            <img src="https://images.unsplash.com/photo-1597481499750-3e6b22637e12?auto=format&fit=crop&w=600&q=80" alt="Bangladeshi Tea Garden" />
            <div className="hero-overlay-card">
              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--success)' }}></div>
                <span style={{ fontSize: '0.75rem', color: 'var(--success)', fontWeight: '700', textTransform: 'uppercase' }}>{t('featuredOrigin')}</span>
              </div>
              <h3 style={{ fontSize: '1.2rem', margin: '4px 0', color: 'white' }}>{lang === 'en' ? 'Sreemangal Tea Leaves' : 'শ্রীমঙ্গলের চা পাতা'}</h3>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{lang === 'en' ? 'Moulvibazar, Sylhet Division. Sourced from organic flatland gardens.' : 'মৌলভীবাজার, সিলেট বিভাগ। সমতলের খাঁটি চা বাগান থেকে সংগৃহীত।'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Cultural Touch Pitch */}
      <div className="glass-panel" style={{ padding: '40px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '30px', margin: '40px 0' }}>
        <div style={{ display: 'flex', gap: '16px' }}>
          <div style={{ color: 'var(--gold)', marginTop: '4px' }}><Award size={32} /></div>
          <div>
            <h3 style={{ fontSize: '1.2rem', color: 'white', marginBottom: '8px' }}>{t('whyChooseUs')}</h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{t('whyChooseUsDesc')}</p>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '16px' }}>
          <div style={{ color: 'var(--gold)', marginTop: '4px' }}><Users size={32} /></div>
          <div>
            <h3 style={{ fontSize: '1.2rem', color: 'white', marginBottom: '8px' }}>{t('artisanEmpower')}</h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{t('artisanEmpowerDesc')}</p>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '16px' }}>
          <div style={{ color: 'var(--gold)', marginTop: '4px' }}><ShieldCheck size={32} /></div>
          <div>
            <h3 style={{ fontSize: '1.2rem', color: 'white', marginBottom: '8px' }}>{t('delivery')}</h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{t('deliveryDesc')}</p>
          </div>
        </div>
      </div>

      {/* Division Explorer Categories */}
      <div className="section-header">
        <span className="section-subtitle">{t('browseCategory')}</span>
        <h2 className="section-title">{t('exploreHeritage')}</h2>
        <p>{t('browseCategoryDesc')}</p>
      </div>

      <div className="category-row">
        {[
          { name: t('catFood'), desc: t('catFoodDesc'), cat: "Food", icon: "🍬" },
          { name: t('catClothing'), desc: t('catClothingDesc'), cat: "Clothing", icon: "🧵" },
          { name: t('catHandicrafts'), desc: t('catHandicraftsDesc'), cat: "Handicrafts", icon: "🏺" },
          { name: t('catOrganic'), desc: t('catOrganicDesc'), cat: "Organic", icon: "🌿" }
        ].map((c, i) => (
          <div key={i} className="glass-panel glass-panel-hover category-card" onClick={() => navigate(`/districts?category=${c.cat}`)}>
            <div className="category-icon-box">{c.icon}</div>
            <div>
              <div className="category-name">{c.name}</div>
              <div className="category-description">{c.desc}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Featured Products */}
      <div className="section-header">
        <span className="section-subtitle">{t('handpickedTitle')}</span>
        <h2 className="section-title">{t('iconicProducts')}</h2>
        <p>{t('iconicProductsDesc')}</p>
      </div>

      <div className="products-grid">
        {featuredProducts.map(p => {
          const isWishlisted = wishlist.includes(p.id);
          return (
            <div className="glass-panel glass-panel-hover product-card" key={p.id}>
              <div className="product-image-container">
                <img src={p.image} alt={p['name_' + lang] || p.name} />
                <span className="product-badge-district">📍 {lang === 'en' ? p.district : (DISTRICTS.find(d => d.name === p.district)?.name_bn || p.district)}</span>
                <span className="product-badge-category">{lang === 'en' ? p.category : (p.category === 'Food' ? 'খাবার' : p.category === 'Clothing' ? 'পোশাক' : p.category === 'Handicrafts' ? 'হস্তশিল্প' : 'প্রাকৃতিক')}</span>
              </div>
              <div className="product-info">
                <div className="product-rating">
                  <Star size={14} fill="currentColor" />
                  <span>{p.rating}</span>
                </div>
                <h3 className="product-title" onClick={() => setSelectedProduct(p)} style={{ cursor: 'pointer' }}>{p['name_' + lang] || p.name}</h3>
                <p className="product-desc">{p['description_' + lang] || p.description}</p>
                <div className="product-footer">
                  <div className="product-price">৳{p.price}</div>
                  <div style={{ display: 'flex', gap: '8px' }}>
                    <button 
                      className="icon-badge-btn" 
                      style={{ border: '1px solid var(--border-color)', color: isWishlisted ? 'var(--accent-red)' : 'white' }}
                      onClick={() => toggleWishlist(p.id)}
                    >
                      <Heart size={16} fill={isWishlisted ? "currentColor" : "none"} />
                    </button>
                    <button className="btn btn-primary" style={{ padding: '8px 12px', fontSize: '0.8rem' }} onClick={() => addToCart(p)}>
                      {t('add')}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div style={{ textAlign: 'center', marginTop: '48px' }}>
        <button className="btn btn-accent" onClick={() => navigate('/districts')}>
          {t('browseAllDistricts')} <ChevronRight size={16} />
        </button>
      </div>

      {/* Testimonials */}
      <div className="section-header">
        <span className="section-subtitle">{t('customerVoices')}</span>
        <h2 className="section-title">{t('testimonialsTitle')}</h2>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '24px' }}>
        <div className="glass-panel" style={{ padding: '24px' }}>
          <p style={{ fontStyle: 'italic', fontSize: '0.9rem', marginBottom: '16px' }}>
            {lang === 'en' 
              ? '"The Bogura Doi arrived in a pristine clay pot, tightly wrapped, still cold! It tasted exactly like what I had years ago in Sherpur. A blessing for foodies."'
              : '"বগুড়ার দই একদম সতেজ মাটির সরায় ঠান্ডা ঠান্ডা ডেলিভারি পেয়েছি! প্যাকেজিং চমৎকার ছিল। কয়েক বছর আগে শেরপুরে খাওয়া আসল দইয়ের স্বাদ হুবহু ফিরে পেলাম। ধন্যবাদ ফেমাস৬৪।"'
            }
          </p>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: 'linear-gradient(135deg, var(--gold) 0%, var(--primary-green) 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold' }}>N</div>
            <div>
              <div style={{ fontWeight: 'bold', fontSize: '0.9rem' }}>{lang === 'en' ? 'Nusrat Jahan' : 'নুসরাত জাহান'}</div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{lang === 'en' ? 'Dhaka, Verified Buyer' : 'ঢাকা, ভেরিফাইড ক্রেতা'}</div>
            </div>
          </div>
        </div>
        <div className="glass-panel" style={{ padding: '24px' }}>
          <p style={{ fontStyle: 'italic', fontSize: '0.9rem', marginBottom: '16px' }}>
            {lang === 'en' 
              ? '"I ordered a Jamalpur Nakshi Kantha for my parents. The stitches are extremely fine, depicting traditional boats and birds. An heirloom piece."'
              : '"আমার মা-বাবার জন্য জামালপুরের সূচিশিল্পের নকশী কাঁথাটি অর্ডার করেছিলাম। বুনন অসম্ভব সুন্দর ও নিখুঁত, গ্রামীণ নৌকা ও ময়ূরের প্রতিচ্ছবি ফুটিয়ে তোলা হয়েছে। নিখাদ ঐতিহ্য।"'
            }
          </p>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: 'linear-gradient(135deg, var(--gold) 0%, var(--primary-green) 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold' }}>R</div>
            <div>
              <div style={{ fontWeight: 'bold', fontSize: '0.9rem' }}>{lang === 'en' ? 'Rajib Ahmed' : 'রাজীব আহমেদ'}</div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{lang === 'en' ? 'Sylhet, Art Collector' : 'সিলেট, সংগ্রাহক'}</div>
            </div>
          </div>
        </div>
        <div className="glass-panel" style={{ padding: '24px' }}>
          <p style={{ fontStyle: 'italic', fontSize: '0.9rem', marginBottom: '16px' }}>
            {lang === 'en'
              ? '"Outstanding platform. Being able to browse by district makes it so educational. The interactive map proposal is what we need for regional tourism!"'
              : '"চমৎকার উদ্যোগ। জেলা ভিত্তিক পণ্য ব্রাউজ করার সুবিধাটি একে একই সাথে শিক্ষণীয় করে তুলেছে। প্রকল্পের বাজেট ক্যালকুলেটর ও ইন্টারেক্টিভ ম্যাপ প্রস্তাবনা দারুণ হয়েছে।"'
            }
          </p>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: 'linear-gradient(135deg, var(--gold) 0%, var(--primary-green) 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold' }}>K</div>
            <div>
              <div style={{ fontWeight: 'bold', fontSize: '0.9rem' }}>{lang === 'en' ? 'Dr. Kabir Chowdhury' : 'ডাঃ কবির চৌধুরী'}</div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{lang === 'en' ? 'Mymensingh, Heritage Researcher' : 'ময়মনসিংহ, গবেষক'}</div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// 4. DISTRICT BROWSER & 64 ITEMS PAGE
const DistrictBrowser = ({ products, addToCart, setSelectedProduct, wishlist, toggleWishlist, lang }) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const activeDivision = searchParams.get('division') || 'Dhaka';
  const activeCategory = searchParams.get('category') || 'All';
  const searchQuery = searchParams.get('search') || '';
  const t = (key) => TRANSLATIONS[lang][key] || key;

  const districtsOfActiveDivision = useMemo(() => {
    return DISTRICTS.filter(d => d.division === activeDivision);
  }, [activeDivision]);

  // Handle selected district
  const initialDistrict = districtsOfActiveDivision[0]?.name || '';
  const [activeDistrict, setActiveDistrict] = useState(initialDistrict);

  // Sync active district when division changes
  useEffect(() => {
    if (districtsOfActiveDivision.length > 0) {
      setActiveDistrict(districtsOfActiveDivision[0].name);
    }
  }, [activeDivision, districtsOfActiveDivision]);

  // Find active district spotlight info
  const activeDistrictSpotlight = useMemo(() => {
    return DISTRICTS.find(d => d.name === activeDistrict) || { name: activeDistrict, name_bn: activeDistrict, famousFor_en: 'Local Treasures', famousFor_bn: 'দেশী সম্পদ', story_en: 'Explore items.', story_bn: 'পণ্য সমূহ।' };
  }, [activeDistrict]);

  // Price range filter
  const [maxPrice, setMaxPrice] = useState(15000);

  // Filter products
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      // search query
      const matchesSearch = searchQuery 
        ? (p.name_en?.toLowerCase().includes(searchQuery.toLowerCase()) || 
           p.name_bn?.includes(searchQuery) ||
           p.district.toLowerCase().includes(searchQuery.toLowerCase()) ||
           (DISTRICTS.find(d => d.name === p.district)?.name_bn || '').includes(searchQuery))
        : true;
      
      // category
      const matchesCategory = activeCategory === 'All' ? true : p.category === activeCategory;
      
      // price
      const matchesPrice = p.price <= maxPrice;

      // When search is active, show matches globally
      if (searchQuery) {
        return matchesSearch && matchesCategory && matchesPrice;
      } else {
        const matchesDistrict = p.district === activeDistrict;
        return matchesDistrict && matchesCategory && matchesPrice;
      }
    });
  }, [products, searchQuery, activeCategory, activeDistrict, maxPrice]);

  const selectDivision = (div) => {
    setSearchParams(prev => {
      prev.set('division', div);
      prev.delete('search'); // Clear search when picking division
      return prev;
    });
  };

  const selectCategory = (cat) => {
    setSearchParams(prev => {
      if (cat === 'All') prev.delete('category');
      else prev.set('category', cat);
      return prev;
    });
  };

  const handleSearchChange = (e) => {
    const val = e.target.value;
    setSearchParams(prev => {
      if (!val) prev.delete('search');
      else prev.set('search', val);
      return prev;
    });
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <div className="section-header" style={{ margin: '20px auto 40px auto' }}>
        <span className="section-subtitle">🇧🇩 {lang === 'en' ? '64 DISTRICT DIRECTORY' : '৬৪ জেলার তালিকা বিবরণী'}</span>
        <h1 className="section-title" style={{ fontSize: '2.8rem' }}>{lang === 'en' ? 'Bangladesh Heritage Catalog' : 'বাংলাদেশের পণ্য সম্ভার'}</h1>
        <p>{lang === 'en' ? 'Browse products by division and district, or filter by category and price range.' : 'বিভাগ ও জেলা ভিত্তিক ঐতিহ্যবাহী খাবার, তাঁতের কাপড় ও কারুশিল্প খুঁজুন।'}</p>
      </div>

      {/* Global Filters bar */}
      <div className="glass-panel" style={{ padding: '20px', marginBottom: '32px', display: 'flex', flexWrap: 'wrap', gap: '20px', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
          {['All', 'Food', 'Clothing', 'Handicrafts', 'Organic'].map(cat => (
            <button 
              key={cat} 
              className={`btn ${activeCategory === cat ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => selectCategory(cat)}
              style={{ padding: '8px 16px', fontSize: '0.85rem' }}
            >
              {cat === 'All' ? t('allCategories') : (cat === 'Food' ? t('catFood') : cat === 'Clothing' ? t('catClothing') : cat === 'Handicrafts' ? t('catHandicrafts') : t('catOrganic'))}
            </button>
          ))}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flex: 1, maxWidth: '300px' }}>
          <span className="form-label" style={{ marginBottom: 0, fontSize: '0.8rem', whiteSpace: 'nowrap' }}>{t('maxPriceLabel')}{maxPrice}</span>
          <input 
            type="range" 
            min="100" 
            max="15000" 
            step="100" 
            className="form-input" 
            style={{ padding: 0, height: '4px', background: 'var(--border-color)', accentColor: 'var(--gold)' }}
            value={maxPrice}
            onChange={e => setMaxPrice(Number(e.target.value))}
          />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', background: 'rgba(255,255,255,0.03)', border: '1px solid var(--border-color)', padding: '6px 12px', borderRadius: '10px', width: '250px' }}>
          <Search size={16} style={{ color: 'var(--text-muted)' }} />
          <input 
            type="text" 
            placeholder={t('searchPlaceholder')} 
            className="search-input-hero"
            style={{ fontSize: '0.85rem' }}
            value={searchQuery}
            onChange={handleSearchChange}
          />
        </div>
      </div>

      <div className="district-browser-layout">
        {/* Left Side: Division Tabs & District Selector */}
        <aside style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <div className="glass-panel division-sidebar">
            <div className="division-header-box">
              <h3 style={{ fontSize: '1.2rem', color: 'white' }}>{lang === 'en' ? '8 Divisions' : '৮টি বিভাগ'}</h3>
            </div>
            <div className="division-list">
              {DIVISIONS.map(div => {
                const count = DISTRICTS.filter(d => d.division === div.id).length;
                return (
                  <div 
                    key={div.id} 
                    className={`division-tab ${activeDivision === div.id && !searchQuery ? 'active' : ''}`}
                    onClick={() => selectDivision(div.id)}
                  >
                    <span>{lang === 'en' ? div.en : div.bn}</span>
                    <span style={{ fontSize: '0.75rem', opacity: 0.6 }}>({lang === 'en' ? `${count} Districts` : `${count} জেলা`})</span>
                  </div>
                );
              })}
            </div>
          </div>
          
          <div style={{ padding: '16px', background: 'rgba(212,175,55,0.02)', border: '1px dashed var(--border-gold)', borderRadius: '16px' }}>
            <h4 style={{ color: 'var(--gold-light)', fontSize: '0.95rem', marginBottom: '8px' }}>💡 {lang === 'en' ? 'Search Hint' : 'সার্চ করার পরামর্শ'}</h4>
            <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
              {lang === 'en' 
                ? 'Type a district name (e.g. "Jessore") in the search box to find all associated regional products!'
                : 'সার্চ বক্সে যেকোনো জেলার নাম (যেমন: "বগুড়া" বা "যশোর") লিখলে ওই জেলার সমস্ত পণ্য একবারে তালিকাভুক্ত দেখতে পাবেন!'
              }
            </p>
          </div>
        </aside>

        {/* Right Side: Districts picker, spotlight and products grid */}
        <div className="district-grid-section">
          {searchQuery ? (
            <div style={{ background: 'rgba(212,175,55,0.05)', padding: '16px 24px', borderRadius: '16px', border: '1px solid var(--border-gold)' }}>
              <h2 style={{ fontSize: '1.25rem', color: 'var(--gold-light)' }}>
                {lang === 'en' ? `Search Results for "${searchQuery}"` : `"${searchQuery}" এর জন্য অনুসন্ধানের ফলাফল`}
              </h2>
              <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                {lang === 'en' ? 'Showing all matching items across all divisions.' : 'দেশব্যাপী মেলা ক্যাটালগ থেকে পাওয়া ফলাফল সমূহ।'}
              </p>
            </div>
          ) : (
            <>
              {/* District capsules grid */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <h4 style={{ fontSize: '0.9rem', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--text-muted)' }}>
                  {t('selectDistrict')} {lang === 'en' ? activeDivision : DIVISIONS.find(d => d.id === activeDivision)?.bn}:
                </h4>
                <div className="district-capsules-grid">
                  {districtsOfActiveDivision.map(d => (
                    <button 
                      key={d.name} 
                      className={`district-capsule ${activeDistrict === d.name ? 'active' : ''}`}
                      onClick={() => setActiveDistrict(d.name)}
                    >
                      {lang === 'en' ? d.name : d.name_bn}
                    </button>
                  ))}
                </div>
              </div>

              {/* Spotlight box */}
              <div className="glass-panel district-spotlight-panel">
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--gold)' }}>
                  <MapPin size={18} />
                  <span style={{ fontSize: '0.85rem', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '1.5px' }}>{t('districtSpotlight')}</span>
                </div>
                <h2 className="district-spotlight-title">{lang === 'en' ? activeDistrictSpotlight.name : activeDistrictSpotlight.name_bn}</h2>
                <div style={{ fontSize: '0.95rem', color: 'white', fontWeight: '600' }}>
                  {lang === 'en' ? 'Famous For: ' : 'বিখ্যাত পণ্য: '} <span style={{ color: 'var(--gold)' }}>{lang === 'en' ? activeDistrictSpotlight.famousFor_en : activeDistrictSpotlight.famousFor_bn}</span>
                </div>
                <p className="district-spotlight-desc">{lang === 'en' ? activeDistrictSpotlight.story_en : activeDistrictSpotlight.story_bn}</p>
              </div>
            </>
          )}

          {/* Products listings */}
          <div>
            <h3 style={{ fontSize: '1.4rem', color: 'white', marginBottom: '20px', borderBottom: '1px solid var(--border-color)', paddingBottom: '10px' }}>
              {t('matchingItems')} ({filteredProducts.length} {t('itemsFound')})
            </h3>
            
            {filteredProducts.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '60px 40px', background: 'rgba(255,255,255,0.01)', borderRadius: '16px', border: '1px dashed var(--border-color)' }}>
                <ShoppingBag size={40} style={{ color: 'var(--text-muted)', marginBottom: '12px' }} />
                <h4 style={{ color: 'white', marginBottom: '4px' }}>{t('noItemsListed')}</h4>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                  {t('noItemsListedDesc')}
                </p>
                <div style={{ marginTop: '16px' }}>
                  <button className="btn btn-outline" style={{ fontSize: '0.8rem' }} onClick={() => { setSearchParams({}); setMaxPrice(15000); }}>{t('resetFilters')}</button>
                </div>
              </div>
            ) : (
              <div className="products-grid">
                {filteredProducts.map(p => {
                  const isWishlisted = wishlist.includes(p.id);
                  return (
                    <div className="glass-panel glass-panel-hover product-card" key={p.id}>
                      <div className="product-image-container">
                        <img src={p.image} alt={p['name_' + lang] || p.name} />
                        <span className="product-badge-district">📍 {lang === 'en' ? p.district : (DISTRICTS.find(d => d.name === p.district)?.name_bn || p.district)}</span>
                        <span className="product-badge-category">{lang === 'en' ? p.category : (p.category === 'Food' ? 'খাবার' : p.category === 'Clothing' ? 'পোশাক' : p.category === 'Handicrafts' ? 'হস্তশিল্প' : 'প্রাকৃতিক')}</span>
                      </div>
                      <div className="product-info">
                        <div className="product-rating">
                          <Star size={14} fill="currentColor" />
                          <span>{p.rating}</span>
                        </div>
                        <h3 className="product-title" onClick={() => setSelectedProduct(p)} style={{ cursor: 'pointer' }}>{p['name_' + lang] || p.name}</h3>
                        <p className="product-desc">{p['description_' + lang] || p.description}</p>
                        <div className="product-footer">
                          <div className="product-price">৳{p.price}</div>
                          <div style={{ display: 'flex', gap: '8px' }}>
                            <button 
                              className="icon-badge-btn" 
                              style={{ border: '1px solid var(--border-color)', color: isWishlisted ? 'var(--accent-red)' : 'white' }}
                              onClick={() => toggleWishlist(p.id)}
                            >
                              <Heart size={16} fill={isWishlisted ? "currentColor" : "none"} />
                            </button>
                            <button className="btn btn-primary" style={{ padding: '8px 12px', fontSize: '0.8rem' }} onClick={() => addToCart(p)}>
                              {t('add')}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// 5. OFFERS PAGE
const Offers = ({ addToCart, setSelectedProduct, products, lang }) => {
  const t = (key) => TRANSLATIONS[lang][key] || key;
  const comboProducts = useMemo(() => {
    return products.filter(p => ["satkhira_honey", "natore_kachagolla", "sylhet_tea_leaves"].includes(p.id));
  }, [products]);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <div className="section-header" style={{ margin: '20px auto 40px auto' }}>
        <span className="section-subtitle">🏷️ {t('offers')}</span>
        <h1 className="section-title">{lang === 'en' ? 'Special Deals & Seasonal Offers' : 'বিশেষ মূল্যছাড় ও অফারসমূহ'}</h1>
        <p>{lang === 'en' ? 'Save on authentic items using our promo codes and purchase discounted bundles.' : 'ঐতিহ্যবাহী কুপন কোড ব্যবহার করে সাশ্রয়ী মূল্যে পণ্য সংগ্রহ করুন।'}</p>
      </div>

      {/* Offer Banner 1 */}
      <div className="glass-panel offer-banner" style={{ background: 'linear-gradient(135deg, rgba(0, 90, 67, 0.9) 0%, rgba(212, 175, 55, 0.15) 100%)' }}>
        <div className="offer-banner-content" style={{ position: 'relative', zIndex: 2 }}>
          <span className="offer-badge">{lang === 'en' ? 'Boishakhi Fest' : 'বৈশাখী উৎসব অফার'}</span>
          <h2 className="offer-title">{lang === 'en' ? 'Save 15% on All Heritage Sweets & Clothes' : 'সকল মিষ্টি ও পোশাক পণ্যে ১৫% মূল্যছাড়'}</h2>
          <p className="offer-desc">
            {lang === 'en' 
              ? 'Celebrate local traditions. Use coupon code DESHI15 at checkout to apply a 15% discount on all orders above BDT 500.'
              : 'দেশী পণ্যের বিশ্বস্ত সমাহার। ক্যাটালগের যেকোনো পণ্য কিনতে চেকআউটে DESHI15 কোডটি লিখে প্রবেশ করান ও ১৫% ডিসকাউন্ট পান।'
            }
          </p>
          <div style={{ padding: '8px 16px', background: 'rgba(9,14,22,0.6)', border: '1px solid var(--border-gold)', display: 'inline-block', borderRadius: '8px', color: 'white', fontSize: '0.9rem' }}>
            {lang === 'en' ? 'Promo Code: ' : 'প্রমো কোড: '} <strong style={{ color: 'var(--gold-light)' }}>DESHI15</strong>
          </div>
        </div>
        <div style={{ fontSize: '7rem', opacity: 0.15, transform: 'rotate(-10deg)', position: 'absolute', right: '40px', bottom: '0px' }}>🌾</div>
      </div>

      {/* Offer Banner 2 */}
      <div className="glass-panel offer-banner" style={{ background: 'linear-gradient(135deg, rgba(17, 24, 39, 0.9) 0%, rgba(225, 29, 72, 0.15) 100%)' }}>
        <div className="offer-banner-content" style={{ position: 'relative', zIndex: 2 }}>
          <span className="offer-badge" style={{ background: 'var(--gold)', color: '#090e16' }}>{lang === 'en' ? 'VIP Heritage' : 'উদ্বোধনী অফার'}</span>
          <h2 className="offer-title">{lang === 'en' ? 'Exclusive Launch Discount: 20% OFF' : 'নতুন প্ল্যাটফর্ম লঞ্চ উপলক্ষে ২০% ডিসকাউন্ট'}</h2>
          <p className="offer-desc">
            {lang === 'en'
              ? 'Enjoy our nationwide platform launch. Get a flat 20% discount on any cart content using the coupon code FAMOUS64.'
              : 'সারা দেশে দেশী পণ্যের নেটওয়ার্ক চালু উপলক্ষে যেকোনো অর্ডারে ফ্ল্যাট ২০% ছাড় উপভোগ করতে FAMOUS64 কুপনটি ব্যবহার করুন।'
            }
          </p>
          <div style={{ padding: '8px 16px', background: 'rgba(9,14,22,0.6)', border: '1px solid var(--border-gold)', display: 'inline-block', borderRadius: '8px', color: 'white', fontSize: '0.9rem' }}>
            {lang === 'en' ? 'Promo Code: ' : 'প্রমো কোড: '} <strong style={{ color: 'var(--gold-light)' }}>FAMOUS64</strong>
          </div>
        </div>
        <div style={{ fontSize: '7rem', opacity: 0.15, transform: 'rotate(15deg)', position: 'absolute', right: '40px', bottom: '0px' }}>🍯</div>
      </div>

      {/* Combo deals */}
      <div className="section-header">
        <span className="section-subtitle">{lang === 'en' ? 'VALUE SAVERS' : 'সাশ্রয়ী বান্ডেল সমূহ'}</span>
        <h2 className="section-title">{lang === 'en' ? 'Heritage Combo Packages' : 'ঐতিহ্যবাহী কম্বো প্যাকেজ'}</h2>
        <p>{lang === 'en' ? 'Buy authentic products packed together at lowered rates (Includes free shipping).' : 'জনপ্রিয় জেলাসমূহের বিখ্যাত জিনিস একই প্যাকেজে সাশ্রয়ী মূল্যে সংগ্রহ করুন (ডেলিভারি ফ্রি)।'}</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px', marginBottom: '4px' }}>
        <div className="glass-panel" style={{ padding: '32px', display: 'flex', flexDirection: 'column', gap: '16px', border: '1px solid var(--border-gold)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <span className="badge badge-success">📦 {lang === 'en' ? 'Sweets & Honey Combo' : 'মিষ্টি ও মধু জুড়ি কম্বো'}</span>
              <h3 style={{ fontSize: '1.4rem', color: 'white', marginTop: '8px' }}>{lang === 'en' ? 'Organic Sundarban & Natore Delights' : 'সুন্দরবনের খাঁটি মধু ও নাটোরের কাঁচাগোল্লা'}</h3>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ textDecoration: 'line-through', color: 'var(--text-muted)', fontSize: '0.9rem' }}>৳১,২৭০</div>
              <div style={{ fontSize: '1.6rem', fontWeight: '800', color: 'var(--gold-light)' }}>৳১,১০০</div>
            </div>
          </div>
          <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
            {lang === 'en'
              ? 'Includes 500ml of Satkhira Sundarban Wild Flower Honey and 1kg of original Natore Rani Bhabani Kachagolla. Freshly packed and delivered together.'
              : 'সাতক্ষীরার সুন্দরবন থেকে সংগৃহীত ৫০০ মিলি বুনো মধু এবং ১ কেজি নাটোরের আদি রানী ভবানী রাজবাড়ির কাঁচাগোল্লা মিষ্টির স্পেশাল প্যাক।'}
          </p>
          <div style={{ marginTop: 'auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '16px', borderTop: '1px solid var(--border-color)' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--success)', fontWeight: '600' }}>✔️ {lang === 'en' ? 'Includes Free Delivery' : 'ডেলিভারি চার্জ সম্পূর্ণ ফ্রি'}</span>
            <button 
              className="btn btn-primary" 
              style={{ padding: '10px 20px' }}
              onClick={() => {
                const honey = comboProducts.find(x => x.id === "satkhira_honey");
                const sweets = comboProducts.find(x => x.id === "natore_kachagolla");
                if (honey) addToCart(honey);
                if (sweets) addToCart(sweets);
                alert(lang === 'en' ? "Combo package added to cart!" : "স্পেশাল কম্বো প্যাকটি কার্টে যোগ করা হয়েছে!");
              }}
            >
              {lang === 'en' ? 'Add Combo to Cart' : 'কম্বো কার্টে যোগ করুন'}
            </button>
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '32px', display: 'flex', flexDirection: 'column', gap: '16px', border: '1px solid var(--border-gold)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <span className="badge badge-success">📦 {lang === 'en' ? 'High-Tea Blend Combo' : 'বিকেলের চা ও মধু আড্ডা কম্বো'}</span>
              <h3 style={{ fontSize: '1.4rem', color: 'white', marginTop: '8px' }}>{lang === 'en' ? 'Sylhet Afternoon High-Tea Selection' : 'শ্রীমঙ্গলের দানাদার চা ও সুন্দরবনের মধু'}</h3>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ textDecoration: 'line-through', color: 'var(--text-muted)', fontSize: '0.9rem' }}>৳১,০৯০</div>
              <div style={{ fontSize: '1.6rem', fontWeight: '800', color: 'var(--gold-light)' }}>৳৯৫০</div>
            </div>
          </div>
          <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
            {lang === 'en'
              ? 'Includes 500g of premium Sreemangal CTC Tea Leaves, 500ml of Satkhira Honey, and a complimentary wooden tea scoop.'
              : 'শ্রীমঙ্গলের সুগন্ধি ৫০০ গ্রাম প্রিমিয়াম ব্ল্যাক চা পাতা ও ৫০০ মিলি সুন্দরবনের খাঁটি মধু। সাথে থাকছে একটি আকর্ষণীয় কাঠের চামচ উপহার।'}
          </p>
          <div style={{ marginTop: 'auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '16px', borderTop: '1px solid var(--border-color)' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--success)', fontWeight: '600' }}>✔️ {lang === 'en' ? 'Includes Free Delivery' : 'ডেলিভারি চার্জ সম্পূর্ণ ফ্রি'}</span>
            <button 
              className="btn btn-primary" 
              style={{ padding: '10px 20px' }}
              onClick={() => {
                const tea = comboProducts.find(x => x.id === "sylhet_tea_leaves");
                const honey = comboProducts.find(x => x.id === "satkhira_honey");
                if (tea) addToCart(tea);
                if (honey) addToCart(honey);
                alert(lang === 'en' ? "High-Tea Combo added to cart!" : "বিকেলের চা আড্ডা কম্বো প্যাকটি কার্টে যোগ করা হয়েছে!");
              }}
            >
              {lang === 'en' ? 'Add Combo to Cart' : 'কম্বো কার্টে যোগ করুন'}
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// 6. BLOG PAGE
const Blog = ({ lang }) => {
  const [activeArticle, setActiveArticle] = useState(null);
  const t = (key) => TRANSLATIONS[lang][key] || key;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <div className="section-header" style={{ margin: '20px auto 40px auto' }}>
        <span className="section-subtitle">✍️ {t('blog')}</span>
        <h1 className="section-title">{lang === 'en' ? 'Famous64 Editorial Blog' : 'ফেমাস৬৪ হেরিটেজ সাময়িকী'}</h1>
        <p>{lang === 'en' ? 'Read about the generational weavers, recipes, and traditions that make Bangladeshi products legendary.' : 'প্রজন্ম থেকে প্রজন্মে চলে আসা কারিগরদের বুনন দক্ষতা ও ঐতিহ্যবাহী লোকগাথার বর্ণিল ইতিহাস।'}</p>
      </div>

      <div className="blog-grid">
        {BLOG_POSTS.map(post => (
          <div className="glass-panel glass-panel-hover blog-card" key={post.id}>
            <div className="blog-img">
              <img src={post.image} alt={post['title_' + lang]} />
            </div>
            <div className="blog-info">
              <div className="blog-meta">
                <span>{lang === 'en' ? `By ${post.author}` : `${post.author}`}</span>
                <span>• {post.date}</span>
                <span>• {post['readTime_' + lang]}</span>
              </div>
              <h2 className="blog-title" style={{ cursor: 'pointer' }} onClick={() => setActiveArticle(post)}>{post['title_' + lang]}</h2>
              <p className="blog-excerpt">{post['excerpt_' + lang]}</p>
              <div style={{ marginTop: 'auto', paddingTop: '16px' }}>
                <button className="btn btn-outline" style={{ width: '100%', fontSize: '0.85rem' }} onClick={() => setActiveArticle(post)}>
                  {lang === 'en' ? 'Read Article' : 'সম্পূর্ণ আর্টিকেল পড়ুন'} <ArrowRight size={14} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Article Detail overlay */}
      <AnimatePresence>
        {activeArticle && (
          <div className="modal-overlay" onClick={() => setActiveArticle(null)}>
            <motion.div 
              className="glass-panel" 
              style={{ maxWidth: '800px', width: '100%', padding: '40px', maxHeight: '85vh', overflowY: 'auto', position: 'relative' }}
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              onClick={e => e.stopPropagation()}
            >
              <button className="modal-close-btn" onClick={() => setActiveArticle(null)}>×</button>
              
              <div style={{ display: 'flex', gap: '12px', fontSize: '0.85rem', color: 'var(--gold)', marginBottom: '12px' }}>
                <span>{activeArticle.date}</span>
                <span>•</span>
                <span>{activeArticle['readTime_' + lang]}</span>
                <span>•</span>
                <span>{lang === 'en' ? `By ${activeArticle.author}` : `${activeArticle.author}`}</span>
              </div>
              <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: '2.5rem', lineHeight: '1.2', color: 'white', marginBottom: '24px' }}>
                {activeArticle['title_' + lang]}
              </h1>
              
              <div style={{ width: '100%', height: '350px', borderRadius: '16px', overflow: 'hidden', marginBottom: '24px' }}>
                <img src={activeArticle.image} alt={activeArticle['title_' + lang]} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              </div>
              
              <p style={{ color: 'var(--text-primary)', fontSize: '1.05rem', lineHeight: '1.8', whiteSpace: 'pre-line' }}>
                {activeArticle['content_' + lang]}
              </p>
              
              <div style={{ marginTop: '32px', padding: '24px', background: 'rgba(212,175,55,0.03)', borderRadius: '12px', border: '1px solid var(--border-gold)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h4 style={{ color: 'white', fontSize: '1.05rem' }}>{lang === 'en' ? 'Enjoyed the story?' : 'গল্পটি কেমন লাগলো?'}</h4>
                  <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{lang === 'en' ? 'Explore authentic items associated with this local craft.' : 'এই অঞ্চলের অন্যান্য বিখ্যাত দেশীয় পণ্য আবিষ্কার করুন।'}</p>
                </div>
                <Link to="/districts" className="btn btn-primary" style={{ padding: '10px 20px', fontSize: '0.85rem' }} onClick={() => setActiveArticle(null)}>
                  {lang === 'en' ? 'Browse Products' : 'পণ্য তালিকা ব্রাউজ করুন'}
                </Link>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

// 7. CONTACT US PAGE
const Contact = ({ lang }) => {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const t = (key) => TRANSLATIONS[lang][key] || key;

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
    }, 1500);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <div className="section-header" style={{ margin: '20px auto 40px auto' }}>
        <span className="section-subtitle">✉️ {t('contact')}</span>
        <h1 className="section-title">{t('contactTitle')}</h1>
        <p>{t('contactDesc')}</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: '40px' }}>
        <div className="glass-panel" style={{ padding: '40px' }}>
          {submitted ? (
            <div style={{ textAlign: 'center', padding: '40px 0' }}>
              <div className="success-icon" style={{ fontSize: '3.5rem', color: 'var(--success)' }}>✓</div>
              <h2 style={{ fontSize: '1.5rem', color: 'white', marginBottom: '12px' }}>{t('sentSuccess')}</h2>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: '24px' }}>
                {t('sentSuccessDesc')}
              </p>
              <button className="btn btn-primary" onClick={() => setSubmitted(false)}>{lang === 'en' ? 'Send Another Message' : 'আরেকটি বার্তা পাঠান'}</button>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <h3 style={{ fontSize: '1.25rem', color: 'white', marginBottom: '24px' }}>{lang === 'en' ? 'Send Us a Message' : 'বার্তা প্রদান করুন'}</h3>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">{t('fullName')}</label>
                  <input 
                    type="text" 
                    required 
                    className="form-input" 
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">{t('emailAddress')}</label>
                  <input 
                    type="email" 
                    required 
                    className="form-input" 
                    value={formData.email}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                  />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">{lang === 'en' ? 'Phone Number (Optional)' : 'মোবাইল নম্বর (ঐচ্ছিক)'}</label>
                  <input 
                    type="text" 
                    className="form-input" 
                    placeholder="01xxxxxxxxx"
                    value={formData.phone}
                    onChange={e => setFormData({...formData, phone: e.target.value})}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">{lang === 'en' ? 'Subject' : 'বিষয়'}</label>
                  <input 
                    type="text" 
                    required 
                    className="form-input" 
                    value={formData.subject}
                    onChange={e => setFormData({...formData, subject: e.target.value})}
                  />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">{lang === 'en' ? 'Message Content' : 'বার্তার বিবরণ'}</label>
                <textarea 
                  required 
                  className="form-textarea" 
                  rows="5"
                  value={formData.message}
                  onChange={e => setFormData({...formData, message: e.target.value})}
                ></textarea>
              </div>
              <button type="submit" className="btn btn-primary" style={{ padding: '12px 32px' }} disabled={loading}>
                {loading ? (lang === 'en' ? 'Submitting...' : 'বার্তা পাঠানো হচ্ছে...') : t('sendMessage')}
              </button>
            </form>
          )}
        </div>

        {/* Contact info details */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <div className="glass-panel" style={{ padding: '32px' }}>
            <h3 style={{ fontSize: '1.25rem', color: 'white', marginBottom: '20px' }}>{t('corporateHeadquarters')}</h3>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '20px', fontSize: '0.95rem' }}>
              <li style={{ display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
                <MapPin size={20} style={{ color: 'var(--gold)', flexShrink: 0, marginTop: '2px' }} />
                <span style={{ color: 'var(--text-secondary)' }}>
                  {lang === 'en' ? (
                    <>Level 8, Deshi Heritage Tower,<br />64 Kamal Ataturk Avenue, Banani,<br />Dhaka - 1213, Bangladesh</>
                  ) : (
                    <>লেভেল ৮, দেশী হেরিটেজ টাওয়ার,<br />৬৪ কামাল আতাতুর্ক এভিনিউ, বনানী,<br />ঢাকা - ১২১৩, বাংলাদেশ</>
                  )}
                </span>
              </li>
              <li style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                <Mail size={20} style={{ color: 'var(--gold)', flexShrink: 0 }} />
                <span style={{ color: 'var(--text-secondary)' }}>sourcing@famous64.com.bd</span>
              </li>
              <li style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                <ShoppingCart size={20} style={{ color: 'var(--gold)', flexShrink: 0 }} />
                <span style={{ color: 'var(--text-secondary)' }}>+880 1764-646464 ({lang === 'en' ? '10 AM - 8 PM' : 'সকাল ১০টা - রাত ৮টা'})</span>
              </li>
            </ul>
          </div>

          <div className="glass-panel" style={{ padding: '32px' }}>
            <h3 style={{ fontSize: '1.25rem', color: 'white', marginBottom: '16px' }}>{t('businessHours')}</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>{t('saturdayThursday')}</span>
                <span style={{ color: 'white', fontWeight: '500' }}>{lang === 'en' ? '09:00 AM - 08:00 PM' : 'সকাল ০৯:০০ - রাত ০৮:০০'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>{lang === 'en' ? 'Friday:' : 'শুক্রবার:'}</span>
                <span style={{ color: 'var(--gold-light)' }}>{t('weeklyHoliday')}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid var(--border-color)', paddingTop: '10px', marginTop: '4px' }}>
                <span>{t('onlineSourcing')}</span>
                <span style={{ color: 'var(--success)', fontWeight: '600' }}>{t('open247')}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// 8. PROPOSAL & LIVE QUOTE CALCULATOR
const Proposal = ({ lang }) => {
  const [selectedModules, setSelectedModules] = useState(() => {
    return PROPOSAL_DATA.quoteModules.filter(m => m.required || m.id === "district_heritage").map(m => m.id);
  });
  const t = (key) => TRANSLATIONS[lang][key] || key;

  const toggleModule = (moduleId) => {
    const isRequired = PROPOSAL_DATA.quoteModules.find(m => m.id === moduleId)?.required;
    if (isRequired) return; // Prevent toggling core module
    
    setSelectedModules(prev => 
      prev.includes(moduleId)
        ? prev.filter(id => id !== moduleId)
        : [...prev, moduleId]
    );
  };

  // Pricing calculations
  const totalCost = useMemo(() => {
    return PROPOSAL_DATA.quoteModules
      .filter(m => selectedModules.includes(m.id))
      .reduce((sum, m) => sum + m.price, 0);
  }, [selectedModules]);

  // Dynamic delivery time estimate based on modules
  const estimatedWeeks = useMemo(() => {
    const coreWeeks = 6;
    let extraWeeks = 0;
    if (selectedModules.includes('seller_panel')) extraWeeks += 2;
    if (selectedModules.includes('mobile_app')) extraWeeks += 3;
    if (selectedModules.includes('multilingual')) extraWeeks += 0.5;
    return coreWeeks + extraWeeks;
  }, [selectedModules]);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="proposal-layout">
      {/* Hero proposal summary */}
      <div className="proposal-hero">
        <span className="section-subtitle">{t('proposalSubtitle')}</span>
        <h1 style={{ fontSize: '3rem', color: 'white', marginBottom: '16px' }}>{t('proposalTitle')}</h1>
        <p style={{ maxWidth: '700px', margin: '0 auto', color: 'var(--text-secondary)' }}>
          {t('proposalDesc')}
        </p>
      </div>

      {/* Quote Builder */}
      <div className="quote-calculator-grid">
        <div>
          <h2 style={{ fontSize: '1.4rem', color: 'white', marginBottom: '20px' }}>
            {t('platformFeatures')}
          </h2>
          <div className="modules-list">
            {PROPOSAL_DATA.quoteModules.map(module => {
              const isSelected = selectedModules.includes(module.id);
              return (
                <div 
                  key={module.id} 
                  className={`glass-panel module-card ${isSelected ? 'selected' : ''}`}
                  onClick={() => toggleModule(module.id)}
                >
                  <div className="module-checkbox">
                    {isSelected && "✓"}
                  </div>
                  <div className="module-info">
                    <div className="module-title-row">
                      <div className="module-name">
                        {module['name_' + lang] || module.name} 
                        {module.required && <span style={{ fontSize: '0.75rem', color: 'var(--accent-red)', marginLeft: '8px' }}>({lang === 'en' ? 'Required' : 'প্রয়োজনীয়'})</span>}
                      </div>
                      <div className="module-price">৳{module.price.toLocaleString(lang === 'en' ? 'en-US' : 'bn-BD')}</div>
                    </div>
                    <div className="module-desc">{module['description_' + lang] || module.description}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sticky pricing summary */}
        <div>
          <div className="glass-panel quote-summary-panel">
            <h3 style={{ fontSize: '1.25rem', color: 'white', margin: 0, borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>
              {t('estimationSummary')}
            </h3>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-secondary)' }}>{t('selectedModules')}</span>
                <span style={{ color: 'white', fontWeight: '600' }}>{selectedModules.length}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-secondary)' }}>{t('estimatedTimeline')}</span>
                <span style={{ color: 'var(--success)', fontWeight: '700' }}>{estimatedWeeks} {lang === 'en' ? 'Weeks' : 'সপ্তাহ'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px dashed var(--border-color)', paddingTop: '16px' }}>
                <span style={{ color: 'var(--text-secondary)', fontSize: '1rem' }}>{t('totalCostLabel')}</span>
                <span style={{ color: 'var(--gold-light)', fontSize: '1.6rem', fontWeight: '800' }}>
                  ৳{totalCost.toLocaleString(lang === 'en' ? 'en-US' : 'bn-BD')}
                </span>
              </div>
            </div>

            <div style={{ background: 'rgba(255,255,255,0.01)', border: '1px solid var(--border-color)', borderRadius: '12px', padding: '16px', fontSize: '0.8rem', color: 'var(--text-muted)', lineHeight: '1.5' }}>
              {t('timelineNotice')}
            </div>

            <button className="btn btn-accent" style={{ width: '100%', padding: '12px' }} onClick={() => window.print()}>
              <FileText size={16} /> {t('printProposal')}
            </button>
          </div>
        </div>
      </div>

      {/* Tech Stack Matrix */}
      <div className="tech-stack-comparison">
        <h2 style={{ fontSize: '1.4rem', color: 'white', marginBottom: '8px' }}>
          {t('recommendedStacks')}
        </h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
          {t('stackCompareDesc')}
        </p>

        <div className="stacks-grid">
          {PROPOSAL_DATA.techStacks.map((stack, i) => (
            <div key={i} className={`glass-panel stack-card ${i === 1 ? 'recommended' : ''}`}>
              {i === 1 && <span className="stack-badge">🌟 {t('recommendedBadge')}</span>}
              <h3 style={{ fontSize: '1.15rem', color: 'white', margin: 0 }}>{stack['name_' + lang]}</h3>
              
              <div>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{lang === 'en' ? 'Typical Launch: ' : 'প্রকল্পের সময়সীমা: '} </span>
                <strong style={{ fontSize: '0.85rem', color: 'var(--gold)' }}>{stack['duration_' + lang]}</strong>
              </div>

              <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', fontStyle: 'italic', borderBottom: '1px solid rgba(255,255,255,0.03)', paddingBottom: '12px' }}>
                {stack['suitability_' + lang]}
              </div>

              <div>
                <h4 style={{ fontSize: '0.85rem', color: 'white', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>{t('pros')}</h4>
                <ul style={{ paddingLeft: '20px', fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  {stack['pros_' + lang].map((p, idx) => <li key={idx}>{p}</li>)}
                </ul>
              </div>

              <div style={{ marginTop: 'auto', paddingTop: '12px' }}>
                <h4 style={{ fontSize: '0.85rem', color: 'white', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>{t('cons')}</h4>
                <ul style={{ paddingLeft: '20px', fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  {stack['cons_' + lang].map((c, idx) => <li key={idx}>{c}</li>)}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Gantt Timeline Stages */}
      <div>
        <h2 style={{ fontSize: '1.4rem', color: 'white', marginBottom: '8px' }}>
          {t('timelineTitle')}
        </h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
          {t('timelineSubtitle')}
        </p>

        <div className="glass-panel timeline-stage-list">
          {PROPOSAL_DATA.timelinePhases.map((phase, i) => (
            <div className="timeline-stage-item" key={i}>
              <div className="timeline-stage-meta">
                <h3 className="timeline-stage-title">{phase['stage_' + lang]}</h3>
                <span className="timeline-stage-duration">⏳ {t('phaseDuration')} {phase['duration_' + lang]}</span>
              </div>
              <div className="timeline-stage-tasks">
                {phase['tasks_' + lang].map((t, idx) => (
                  <div key={idx} style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                    <div style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'var(--gold)' }}></div>
                    <span>{t}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

// 9. CHECKOUT PAGE SIMULATOR
const Checkout = ({ cart, clearCart, orders, setOrders, lang }) => {
  const [formData, setFormData] = useState({ name: '', phone: '', email: '', division: 'Dhaka', district: '', address: '' });
  const [payment, setPayment] = useState('bkash');
  const [orderComplete, setOrderComplete] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const t = (key) => TRANSLATIONS[lang][key] || key;

  const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const shipping = subtotal > 0 ? 80 : 0;
  const total = subtotal + shipping;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (cart.length === 0) return;
    
    setLoading(true);
    setTimeout(() => {
      const newOrderId = `ORD-${Math.floor(1000 + Math.random() * 9000)}`;
      const orderRecord = {
        id: newOrderId,
        name: formData.name,
        phone: formData.phone,
        total: total,
        itemsCount: cart.reduce((sum, item) => sum + item.quantity, 0),
        payment: payment === 'bkash' ? 'bKash' : payment === 'nagad' ? 'Nagad' : payment === 'card' ? 'Visa/Mastercard' : 'Cash on Delivery',
        status: "Pending",
        date: new Date().toISOString().split('T')[0]
      };
      
      setOrders([orderRecord, ...orders]);
      setOrderComplete(orderRecord);
      clearCart();
      setLoading(false);
    }, 1500);
  };

  if (orderComplete) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', padding: '40px 0' }}>
        <div className="glass-panel success-card">
          <div className="success-icon">✓</div>
          <h2 style={{ fontSize: '1.8rem', color: 'white', marginBottom: '12px' }}>{t('orderPlaced')}</h2>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
            {t('orderPlacedDesc')}
          </p>
          
          <div className="invoice-box">
            <h3 style={{ fontSize: '1rem', color: 'var(--gold-light)', borderBottom: '1px solid var(--border-color)', paddingBottom: '8px', marginBottom: '12px' }}>{t('billSummary')}</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>{t('orderRef')}</span><strong>{orderComplete.id}</strong></div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>{t('fullName')}:</span><span>{orderComplete.name}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>{lang === 'en' ? 'Contact Phone:' : 'যোগাযোগ মোবাইল:'}</span><span>{orderComplete.phone}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>{lang === 'en' ? 'Payment Gateway:' : 'পেমেন্ট গেটওয়ে:'}</span><span style={{ color: 'var(--gold)' }}>{orderComplete.payment}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px dashed var(--border-color)', paddingTop: '8px', marginTop: '4px' }}><span>{t('paidTotal')}</span><strong>৳{orderComplete.total}</strong></div>
            </div>
          </div>

          <button className="btn btn-primary" onClick={() => navigate('/districts')}>
            {t('backToCatalog')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: '2.5rem', marginBottom: '24px', color: 'white' }}>{t('secureCheckoutTitle')}</h1>
      
      {cart.length === 0 ? (
        <div className="glass-panel" style={{ padding: '40px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <ShoppingCart size={48} style={{ opacity: 0.3, marginBottom: '16px' }} />
          <h2 style={{ fontSize: '1.3rem', color: 'white', marginBottom: '8px' }}>{t('emptyCart')}</h2>
          <button className="btn btn-primary" onClick={() => navigate('/districts')}>{t('browseAllDistricts')}</button>
        </div>
      ) : (
        <div className="checkout-grid">
          {/* Shipping form */}
          <div className="glass-panel" style={{ padding: '40px' }}>
            <form onSubmit={handleSubmit}>
              <h3 className="form-section-title">{t('shippingInfo')}</h3>
              
              <div className="form-group">
                <label className="form-label">{t('fullName')}</label>
                <input 
                  type="text" 
                  required 
                  className="form-input" 
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">{t('phoneNumber')}</label>
                  <input 
                    type="tel" 
                    required 
                    className="form-input" 
                    placeholder="01xxxxxxxxx"
                    value={formData.phone}
                    onChange={e => setFormData({...formData, phone: e.target.value})}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">{t('emailAddress')}</label>
                  <input 
                    type="email" 
                    required 
                    className="form-input" 
                    value={formData.email}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">{t('division')}</label>
                  <select 
                    className="form-input" 
                    style={{ background: '#0f172a' }}
                    value={formData.division}
                    onChange={e => setFormData({...formData, division: e.target.value})}
                  >
                    {DIVISIONS.map(div => <option key={div.id} value={div.id}>{lang === 'en' ? div.en : div.bn}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">{t('district')}</label>
                  <input 
                    type="text" 
                    required 
                    className="form-input" 
                    placeholder={lang === 'en' ? 'e.g. Dhaka, Bogura' : 'যেমন: ঢাকা, বগুড়া'}
                    value={formData.district}
                    onChange={e => setFormData({...formData, district: e.target.value})}
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">{t('fullAddress')}</label>
                <textarea 
                  required 
                  className="form-textarea" 
                  value={formData.address}
                  onChange={e => setFormData({...formData, address: e.target.value})}
                ></textarea>
              </div>

              <h3 className="form-section-title" style={{ marginTop: '40px' }}>{t('paymentIntegration')}</h3>
              <div className="payment-methods-grid">
                <div className={`payment-method-card ${payment === 'bkash' ? 'active' : ''}`} onClick={() => setPayment('bkash')}>
                  <div className="payment-method-logo bkash-text">bKash</div>
                  <div className="payment-method-name">{lang === 'en' ? 'Mobile Wallet' : 'মোবাইল ওয়ালেট'}</div>
                </div>
                <div className={`payment-method-card ${payment === 'nagad' ? 'active' : ''}`} onClick={() => setPayment('nagad')}>
                  <div className="payment-method-logo nagad-text">Nagad</div>
                  <div className="payment-method-name">{lang === 'en' ? 'Mobile Wallet' : 'মোবাইল ওয়ালেট'}</div>
                </div>
                <div className={`payment-method-card ${payment === 'card' ? 'active' : ''}`} onClick={() => setPayment('card')}>
                  <div className="payment-method-logo card-text">Cards</div>
                  <div className="payment-method-name">SSLCommerz</div>
                </div>
                <div className={`payment-method-card ${payment === 'cod' ? 'active' : ''}`} onClick={() => setPayment('cod')}>
                  <div className="payment-method-logo cod-text">COD</div>
                  <div className="payment-method-name">{lang === 'en' ? 'Cash on Delivery' : 'ক্যাশ অন ডেলিভারি'}</div>
                </div>
              </div>

              <button type="submit" className="btn btn-accent" style={{ width: '100%', padding: '14px', borderRadius: '12px', marginTop: '40px' }} disabled={loading}>
                {loading ? (lang === 'en' ? 'Processing Secure Payment...' : 'নিরাপদ পেমেন্ট প্রসেস হচ্ছে...') : `${t('completeOrder')}${total}`}
              </button>
            </form>
          </div>

          {/* Checkout sidebar list */}
          <div>
            <div className="glass-panel" style={{ padding: '32px' }}>
              <h3 style={{ fontSize: '1.25rem', color: 'white', marginBottom: '20px', borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>{t('orderSummary')}</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                {cart.map(item => (
                  <div key={item.product.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem' }}>
                    <span style={{ color: 'var(--text-secondary)', maxWidth: '70%' }}>{item.product['name_' + lang] || item.product.name} (x{item.quantity})</span>
                    <span style={{ fontWeight: '600' }}>৳{item.product.price * item.quantity}</span>
                  </div>
                ))}
                
                <div style={{ borderTop: '1px dashed var(--border-color)', paddingTop: '16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                    <span>{lang === 'en' ? 'Subtotal:' : 'উপ-মোট:'}</span>
                    <span>৳{subtotal}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                    <span>{lang === 'en' ? 'Delivery Charge:' : 'ডেলিভারি চার্জ:'}</span>
                    <span>৳{shipping}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid var(--border-color)', paddingTop: '12px', fontSize: '1.25rem', fontWeight: '800', color: 'white' }}>
                    <span>{t('totalDue')}</span>
                    <span>৳{total}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
};

// 10. SELLER & ADMIN PANEL SIMULATOR
const Admin = ({ products, orders, addProductAdmin, updateOrderStatus, lang }) => {
  const [activeTab, setActiveTab] = useState('orders'); // 'orders' or 'add_product'
  const [prodForm, setProdForm] = useState({ name_en: '', name_bn: '', price: '', category: 'Food', district: 'Dhaka', description_en: '', description_bn: '', history_en: '', history_bn: '', details_en: '', details_bn: '' });
  const [successMsg, setSuccessMsg] = useState('');
  const t = (key) => TRANSLATIONS[lang][key] || key;

  const handleAddProduct = (e) => {
    e.preventDefault();
    if (!prodForm.name_en || !prodForm.name_bn || !prodForm.price || !prodForm.district) return;

    const matchedDist = DISTRICTS.find(d => d.name === prodForm.district);
    const division = matchedDist ? matchedDist.division : 'Dhaka';

    const newProd = {
      id: `custom_${Date.now()}`,
      name_en: prodForm.name_en,
      name_bn: prodForm.name_bn,
      price: Number(prodForm.price),
      category: prodForm.category,
      district: prodForm.district,
      division: division,
      description_en: prodForm.description_en || 'Authentic regional item celebrating Bangladeshi heritage.',
      description_bn: prodForm.description_bn || 'ঐতিহ্যবাহী দেশীয় পণ্য সম্ভার।',
      history_en: prodForm.history_en || 'Traditional preparation process guarded by local makers.',
      history_bn: prodForm.history_bn || 'প্রজন্ম থেকে প্রজন্মে চলে আসা প্রস্তুত প্রণালী।',
      image: prodForm.category === 'Food' ? 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=600&q=80' : 
             prodForm.category === 'Clothing' ? 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=600&q=80' :
             prodForm.category === 'Organic' ? 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80' :
             'https://images.unsplash.com/photo-1600121848594-d8644e57abab?auto=format&fit=crop&w=600&q=80',
      rating: 4.8,
      reviewsCount: 1,
      stock: 15,
      details_en: prodForm.details_en || 'Weight: 1kg | Freshly prepared',
      details_bn: prodForm.details_bn || 'ওজন: ১ কেজি | তাজা প্রস্তুত'
    };

    addProductAdmin(newProd);
    setSuccessMsg(t('productAddedSuccess'));
    setProdForm({ name_en: '', name_bn: '', price: '', category: 'Food', district: 'Dhaka', description_en: '', description_bn: '', history_en: '', history_bn: '', details_en: '', details_bn: '' });
    
    setTimeout(() => {
      setSuccessMsg('');
    }, 3000);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <div className="section-header" style={{ margin: '20px auto 40px auto' }}>
        <span className="section-subtitle">⚙️ {lang === 'en' ? 'MOCK CONTROL PANEL' : 'সিস্টেম কন্ট্রোল প্যানেল'}</span>
        <h1 className="section-title">{t('adminPanelTitle')}</h1>
        <p>{t('adminPanelDesc')}</p>
      </div>

      {/* Numerical statistics widgets */}
      <div className="admin-grid">
        <div className="glass-panel admin-stat-card">
          <span className="admin-stat-title">{t('totalSalesStat')}</span>
          <span className="admin-stat-val" style={{ color: 'var(--success)' }}>
            ৳{orders.reduce((sum, o) => sum + o.total, 0).toLocaleString(lang === 'en' ? 'en-US' : 'bn-BD')}
          </span>
        </div>
        <div className="glass-panel admin-stat-card">
          <span className="admin-stat-title">{t('incomingOrdersStat')}</span>
          <span className="admin-stat-val">{orders.length.toLocaleString(lang === 'en' ? 'en-US' : 'bn-BD')}</span>
        </div>
        <div className="glass-panel admin-stat-card">
          <span className="admin-stat-title">{t('listedProductsStat')}</span>
          <span className="admin-stat-val" style={{ color: 'var(--gold)' }}>{products.length.toLocaleString(lang === 'en' ? 'en-US' : 'bn-BD')}</span>
        </div>
        <div className="glass-panel admin-stat-card">
          <span className="admin-stat-title">{t('activeDistrictsStat')}</span>
          <span className="admin-stat-val" style={{ color: 'var(--primary-green-light)' }}>{lang === 'en' ? '64' : '৬৪'}</span>
        </div>
      </div>

      {/* Tabs list */}
      <div className="glass-panel" style={{ padding: '8px', display: 'flex', gap: '8px', marginBottom: '32px', maxWidth: '350px' }}>
        <button 
          className={`btn ${activeTab === 'orders' ? 'btn-primary' : 'btn-outline'}`}
          onClick={() => setActiveTab('orders')}
          style={{ flex: 1, padding: '10px' }}
        >
          {t('manageOrdersTab')}
        </button>
        <button 
          className={`btn ${activeTab === 'add_product' ? 'btn-primary' : 'btn-outline'}`}
          onClick={() => setActiveTab('add_product')}
          style={{ flex: 1, padding: '10px' }}
        >
          {t('addProductTab')}
        </button>
      </div>

      {activeTab === 'orders' ? (
        <div className="glass-panel" style={{ padding: '24px' }}>
          <h2 style={{ fontSize: '1.25rem', color: 'white', marginBottom: '20px' }}>{t('recentOrders')}</h2>
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>{lang === 'en' ? 'Order Reference' : 'অর্ডার রেফারেন্স'}</th>
                  <th>{lang === 'en' ? 'Customer Name' : 'গ্রাহকের নাম'}</th>
                  <th>{lang === 'en' ? 'Contact Info' : 'যোগাযোগ নম্বর'}</th>
                  <th>{lang === 'en' ? 'Total Due' : 'মোট বিল'}</th>
                  <th>{lang === 'en' ? 'Status' : 'অর্ডার স্ট্যাটাস'}</th>
                  <th>{lang === 'en' ? 'Date' : 'তারিখ'}</th>
                  <th>{lang === 'en' ? 'Quick Action' : 'স্ট্যাটাস পরিবর্তন'}</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(o => (
                  <tr key={o.id}>
                    <td style={{ fontWeight: 'bold' }}>{o.id}</td>
                    <td>{o.name}</td>
                    <td>{o.phone}</td>
                    <td style={{ fontWeight: 'bold', color: 'var(--gold-light)' }}>৳{o.total}</td>
                    <td>
                      <span className="badge" style={{ 
                        background: o.status === 'Pending' ? 'rgba(251,191,36,0.1)' : o.status === 'Shipped' ? 'rgba(59,130,246,0.1)' : 'rgba(16,185,129,0.1)',
                        color: o.status === 'Pending' ? 'var(--warning)' : o.status === 'Shipped' ? '#60a5fa' : 'var(--success)',
                        border: '1.5px solid currentColor'
                      }}>
                        {o.status === 'Pending' ? (lang === 'en' ? 'Pending' : 'অপেক্ষমাণ') : o.status === 'Shipped' ? (lang === 'en' ? 'Shipped' : 'পাঠানো হয়েছে') : (lang === 'en' ? 'Delivered' : 'ডেলিভারি সম্পন্ন')}
                      </span>
                    </td>
                    <td>{o.date}</td>
                    <td>
                      <select 
                        className="form-input" 
                        style={{ padding: '6px 12px', fontSize: '0.8rem', background: '#090e16', width: '130px' }}
                        value={o.status}
                        onChange={e => updateOrderStatus(o.id, e.target.value)}
                      >
                        <option value="Pending">{lang === 'en' ? 'Pending' : 'অপেক্ষমাণ'}</option>
                        <option value="Shipped">{lang === 'en' ? 'Shipped' : 'পাঠানো হয়েছে'}</option>
                        <option value="Delivered">{lang === 'en' ? 'Delivered' : 'ডেলিভারি সম্পন্ন'}</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="glass-panel" style={{ padding: '40px' }}>
          <form onSubmit={handleAddProduct}>
            <h2 style={{ fontSize: '1.25rem', color: 'white', marginBottom: '24px' }}>{t('onboardProduct')}</h2>
            
            {successMsg && (
              <div style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid var(--success)', color: 'var(--success)', padding: '12px', borderRadius: '8px', marginBottom: '24px', fontSize: '0.9rem' }}>
                {successMsg}
              </div>
            )}

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">{lang === 'en' ? 'Product Name (English)' : 'পণ্যের নাম (ইংরেজি)'}</label>
                <input 
                  type="text" 
                  required 
                  className="form-input" 
                  placeholder="e.g. Porabari Chomchom"
                  value={prodForm.name_en}
                  onChange={e => setProdForm({...prodForm, name_en: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label className="form-label">{lang === 'en' ? 'Product Name (Bangla)' : 'পণ্যের নাম (বাংলা)'}</label>
                <input 
                  type="text" 
                  required 
                  className="form-input" 
                  placeholder="যেমন: পোড়াবাড়ির চমচম"
                  value={prodForm.name_bn}
                  onChange={e => setProdForm({...prodForm, name_bn: e.target.value})}
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">{t('priceLabel')}</label>
                <input 
                  type="number" 
                  required 
                  className="form-input" 
                  placeholder="e.g. 450"
                  value={prodForm.price}
                  onChange={e => setProdForm({...prodForm, price: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label className="form-label">{lang === 'en' ? 'Category' : 'ক্যাটাগরি'}</label>
                <select 
                  className="form-input" 
                  style={{ background: '#0f172a' }}
                  value={prodForm.category}
                  onChange={e => setProdForm({...prodForm, category: e.target.value})}
                >
                  <option value="Food">{t('catFood')}</option>
                  <option value="Clothing">{t('catClothing')}</option>
                  <option value="Handicrafts">{t('catHandicrafts')}</option>
                  <option value="Organic">{t('catOrganic')}</option>
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">{lang === 'en' ? 'District Sourced' : 'উৎস জেলা'}</label>
                <select 
                  className="form-input" 
                  style={{ background: '#0f172a' }}
                  value={prodForm.district}
                  onChange={e => setProdForm({...prodForm, district: e.target.value})}
                >
                  {DISTRICTS.map(d => <option key={d.name} value={d.name}>{lang === 'en' ? d.name : d.name_bn}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">{t('availabilitySpec')} (English)</label>
                <input 
                  type="text" 
                  className="form-input" 
                  placeholder="e.g. Weight: 1kg Box | Preservative Free"
                  value={prodForm.details_en}
                  onChange={e => setProdForm({...prodForm, details_en: e.target.value})}
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">{t('availabilitySpec')} (Bangla)</label>
                <input 
                  type="text" 
                  className="form-input" 
                  placeholder="যেমন: ওজন: ১ কেজি বক্স | প্রিজারভেটিভ মুক্ত"
                  value={prodForm.details_bn}
                  onChange={e => setProdForm({...prodForm, details_bn: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label className="form-label">{t('shortDesc')} (English)</label>
                <input 
                  type="text" 
                  className="form-input" 
                  placeholder="Brief summary..."
                  value={prodForm.description_en}
                  onChange={e => setProdForm({...prodForm, description_en: e.target.value})}
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">{t('shortDesc')} (Bangla)</label>
                <input 
                  type="text" 
                  className="form-input" 
                  placeholder="সংক্ষিপ্ত বিবরণ..."
                  value={prodForm.description_bn}
                  onChange={e => setProdForm({...prodForm, description_bn: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label className="form-label">{lang === 'en' ? 'Heritage Origin Story (English)' : 'ঐতিহাসিক ব্যাকগ্রাউন্ড (ইংরেজি)'}</label>
                <textarea 
                  className="form-textarea" 
                  placeholder="History in English..."
                  value={prodForm.history_en}
                  onChange={e => setProdForm({...prodForm, history_en: e.target.value})}
                ></textarea>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">{lang === 'en' ? 'Heritage Origin Story (Bangla)' : 'ঐতিহাসিক ব্যাকগ্রাউন্ড (বাংলা)'}</label>
              <textarea 
                className="form-textarea" 
                placeholder="ইতিহাস বাংলায়..."
                value={prodForm.history_bn}
                onChange={e => setProdForm({...prodForm, history_bn: e.target.value})}
              ></textarea>
            </div>

            <button type="submit" className="btn btn-primary" style={{ padding: '12px 32px' }}>
              {t('publishProduct')}
            </button>
          </form>
        </div>
      )}
    </motion.div>
  );
};

export default App;
